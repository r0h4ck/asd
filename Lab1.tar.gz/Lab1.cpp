﻿// Lab1.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <algorithm>
#include <cmath>
#include <ctime>
using namespace std;
int step = 0;
int *d_arr;
void get_arr(int *mass, int n)
{
	cout << "You array is: \n";
	for (int i = 0; i < n; i++)
	{
		cout << mass[i] << " ";
	}
	cout << endl;
}
void menu()
{
	cout << "Select the sort method\n";
	cout << "For insert sorting enter '1'\n";
	cout << "For selection sorting enter '2'\n";
	cout << "For bubble sorting enter '3'\n";
	cout << "For Shell's sorting enter '4'\n";
	cout << "For quick corting enter '5'\n";
	cout << "For print your array enter '6'\n";
	cout << "For create new array enter '7'\n";
	cout << "For clear console enter '8'\n";
	cout << "For end program enter '0'\n";
}
void insert(int *(&mass), int n)
{
	int temp;
	for (int i = 0; i < n; i++)
	{
		int k = i;
		for (int k = i; k >= 0; k--)
		{
			if (mass[k] < mass[k - 1])
			{
				temp = mass[k];
				mass[k] = mass[k-1];
				mass[k-1] = temp;
				step++;
			}
			else break;
		}
	}
}
void selection(int *(&mass), int n)
{
	int min;
	int temp;
	for (int i = 0; i < n; i++)
	{
		min = i;
		for (int j = i + 1; j < n; j++)
		{
			if (mass[min] > mass[j])
			{
				min = j;
			}
		}
		temp = mass[i];
		mass[i] = mass[min];
		mass[min] = temp;
	}
}
void bubble(int *(&mass), int n)
{
	int temp;
	for (int i = 1; i < n; i++)
	{
		for (int j = 0; j < n-i; j++)
		{
			if (mass[j] > mass[j + 1])
			{
				temp = mass[j];
				mass[j] = mass[j + 1];
				mass[j + 1] = temp;
			}
		}
	}

}
void Shell_3(int *(&mass), int n)
{
	int k = 1;
	int temp;
	while (3*k <= n) {
		k = 3 * k + 1;
	}
	while (k > 0)
	{
		for (int i = k; i < n; i++)
		{
			for (int j = i - k; (j >= 0) && mass[j] > mass[j + k]; j -= k)
			{
					temp = mass[j];
					mass[j] = mass[j + k];
					mass[j + k] = temp;
			}
		}
		k = k / 3;
	}


}	
void Shell_2(int *(&mass), int n)
{
	int k = 1;
	int a = log2(n) - 1;
	int temp;
	while (a>0) {
		k = 2 * k + 1;
		a--;
	}
	while (k > 0)
	{
		for (int i = k; i < n; i++)
		{
			for (int j = i - k; (j >= 0) && mass[j] > mass[j + k]; j -= k)
			{
				
				temp = mass[j];
				mass[j] = mass[j + k];
				mass[j + k] = temp;
			}
		}
		k = k / 2;
	}
}
void quick(int *(&mass), int last, int first)
{
	int l = last;
	int f = first;
	int pivot = mass[(l + f) / 2];
	int temp;
	while (f <= l)
	{
		while (mass[f] < pivot) f++;
		while (mass[l] > pivot) l--;
		if (f <= l)
		{
			temp = mass[f];
			mass[f] = mass[l];
			mass[l] = temp;
			f++; l--;
		}
	}
	if (l > first) quick(*(&mass), l, first);
	if (f < last) quick(*(&mass), last, f);
}
int main()
{
	int *mass;
	int *mass2;
	int amount=0;
	int answ=0, time1=0, time2=0;
	srand(time(0));
	menu();
	cout << "Enter amount of elements: ";
	cin >> amount;
	mass = new int[amount];
	mass2 = new int[amount];
	for (int i = 0; i < amount; i++)
	{
		mass2[i]=mass[i] = rand();
	}
	cout << "Your array is created\n";

	while (true)
	{
		cout << ">>>>";
		cin >> answ;
		switch (answ)
		{
		case 1:
		{
			time1 = clock();
			insert(mass, amount);
			time2 = clock();
		    cout << "Time of sorting: "<<((double)time2 / CLOCKS_PER_SEC) - ((double)time1 / CLOCKS_PER_SEC)<<" s"<<endl;
			break;
		}
		case 2:
		{
			time1 = clock();
			selection(mass, amount);
			time2 = clock();
			cout << "Time of sorting: " << ((double)time2 / CLOCKS_PER_SEC) - ((double)time1 / CLOCKS_PER_SEC) << " s" << endl;
			break;

		}
		case 3:
		{
			time1 = clock();
			bubble(mass, amount);
			time2 = clock();
			cout << "Time of sorting: " << ((double)time2 / CLOCKS_PER_SEC) - ((double)time1 / CLOCKS_PER_SEC) << " s" << endl;
			break;
		}
		case 4:
		{
			time1 = clock();
			Shell_3(mass, amount);
			time2 = clock();
			cout << "Time of sorting (3K+1): " << ((double)time2 / CLOCKS_PER_SEC) - ((double)time1 / CLOCKS_PER_SEC) << " s" << endl;
			time1 = clock();
			Shell_2(mass2, amount);
			time2 = clock();
			cout << "Time of sorting (2K+1): " << ((double)time2 / CLOCKS_PER_SEC) - ((double)time1 / CLOCKS_PER_SEC) << " s" << endl;
			break;
		}
		case 5:
		{
			time1 = clock();
			quick(mass, amount-1, 0);
			time2 = clock();
			cout << "Time of sorting: " << ((double)time2 / CLOCKS_PER_SEC) - ((double)time1 / CLOCKS_PER_SEC) << " s" << endl;
			break;
		}
		case 6:
		{
			get_arr(mass, amount);
			break;
		}
		case 7:
		{
			delete[] mass;
			delete[] mass2;
			cout << "Enter amount of elements: ";
			cin >> amount;
			mass = new int[amount];
			mass2 = new int[amount];
			for (int i = 0; i < amount; i++)
			{
				mass2[i]=mass[i] = rand();
			}
			cout << "Your array is created\n";
			break;
		}
		case 8:
		{
			system("cls");
			menu();
			break;
		}
		case 0:
		{
			exit(0);
			break;
		}
		}
		
	}
}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
