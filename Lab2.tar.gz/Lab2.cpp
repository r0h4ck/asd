﻿// Lab2.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//
//#include "pch.h"
#include <iostream>
#include "List.h"
#include "Stack_array.h"
#include "Stack_list.h"
#include "Queue_array.h"
#include "Queue_list.h"
#include <stack>
#include <queue>


using namespace std;

void Postfix()
{
    //////////// (A+B)*C-(D+E)/F
    ////////////  AB+C*DE+F/- 
    //AB+ =R1
    //R1 C*=R2
    //DE+ =R3
    //R3 F/=R4
    //R2 R4- =RESULT
    int a, b, c, d, e, f;
    cout << "Enter a: ";
    cin >> a;
    cout << "enter b: ";
    cin >> b;
    cout << "enter c: ";
    cin >> c;
    cout << "enter d: ";
    cin >> d;
    cout << "enter e: ";
    cin >> e;
    cout << "enter f: ";
    cin >> f;
    Stack_array S;
    S=Push1(S, f);
    S=Push1(S, e);
    S=Push1(S, d);
    S=Push1(S, c);
    S=Push1(S, b);
    S=Push1(S, a);
    S.cnt--;
    int A = S.S[S.cnt];
    S = Pop1(S);
    int B = S.S[S.cnt];
    S= Pop1(S);
    S=Push1(S, A + B);
    int R1 = S.S[S.cnt]; 
    S = Pop1(S);
    int C = S.S[S.cnt]; 
    S=Pop1(S);
    S=Push1(S, R1 * C);
    int R2 = S.S[S.cnt]; 
    S=Pop1(S);
    int D = S.S[S.cnt]; 
    S=Pop1(S);
    int E = S.S[S.cnt]; 
    S=Pop1(S);
    S=Push1(S, D + E);
    int R3 = S.S[S.cnt]; 
    S=Pop1(S);
    int F = S.S[S.cnt];
    S=Pop1(S);
    S=Push1(S, R3 / F);
    int R4 = S.S[S.cnt]; 
    S=Pop1(S);
    S=Push1(S, R2 - R4);
    Stack_view1(S);
}

int main()
{
    //Stack_array D1;
    //Stack_list D2;
    //Queue_array D11;
    //Queue_list D22;
    //Push1(D1, 3);
    //D2.Push(2);
    //Enqueue1(D11, 1);
    //D22.Enqueue(0);
    ////Postfix();
    //cin.get();
    //cin.get();

    //STL stack
    stack<int> S;
    S.push(55);
    S.push(38);
    cout << S.top() << endl;
    S.pop();
    cout << S.top() << endl;
    S.empty();

    //STL queue
    queue<int> Q;
    Q.push(55);
    Q.push(38);
    cout << Q.front() << endl;
    Q.pop();
    cout << Q.front() << endl;
    Q.empty();


    return 0;
}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.




