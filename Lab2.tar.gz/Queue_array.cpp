//#include "pch.h"
#include "Queue_array.h"
#include <iostream>
using namespace std;

bool Queue_Empty1(Queue_array A)
{
    if (A.head == A.tail) return true;
    else return false;
}

bool Queue_Full1(Queue_array A)
{
    if (A.head == (A.tail + 1) % 20) return true;
    else return false;
}

void Enqueue1(Queue_array A, int x)
{
    if (Queue_Full1(A))
    {
        cout << "OVERQUEUE" << endl;
    }
    else
    {
        A.Q[A.tail] = x;
        if (A.tail == 20)
        {
            A.tail = 1;
        }
        else
        {
            A.tail++;
        }
    }
}

int Dequeue1(Queue_array A)
{
    int x = A.head;
    if (A.head == 20)
    {
        A.head = 1;
    }
    else
    {
        A.head++;
    }
    return x;
}

void Queue_view1(Queue_array A)
{
    if (A.head < A.tail)
    {
        for (int i = A.head; i < A.tail-A.head; i++)
        {
            cout << A.Q[i] << "  ";
        }
    }
    else if (A.head>A.tail)
    {
        for (int i = A.head; i < (20 - A.head + A.tail + 1); i++)
        {
            cout << A.Q[i % 20] << "  ";
        }
    }
    else //if head==tail
    {
        cout << "QUEUE IS EMPTY";
    }
    cout << endl;
}
