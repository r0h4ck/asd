#pragma once
struct Queue_array
{

    int Q[20] = {};
    int head, tail;

    Queue_array()
    {
        head = tail = 0;
    }

};

bool Queue_Empty1(Queue_array A);
bool Queue_Full1(Queue_array A);
void Enqueue1(Queue_array A, int x);
int Dequeue1(Queue_array A);
void Queue_view1(Queue_array A);

