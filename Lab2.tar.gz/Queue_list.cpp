//#include "pch.h"
#include "Queue_list.h"
#include <iostream>
using namespace std;

//bool Queue_Empty2(Queue_list A)
//{
//	if (A.head == A.tail) return true;
//	else return false;
//}
//
//bool Queue_Full2(Queue_list A)
//{
//	if (A.head == (A.tail + 1) % 20) return true;
//	else return false;
//}
//
//void Enqueue2(Queue_list A, int x)
//{
//    if (Queue_Full2(A))
//    {
//        cout << "OVERQUEUE" << endl;
//    }
//    else
//    {
//        A.Q.push_back(x);
//    }
//}
//
//int Dequeue2(Queue_list A)
//{
//    int x = A.head;
//    A.Q.pop_back();
//    return x;
//}

void Queue_list::Enqueue(int data)
{
	if (Queue_Full())
	{
		cout << "Queue is already full" << endl;
	}
	else
	{
		if (hd == nullptr)
		{
			hd = new Node(data);
		}
		else
		{
			Node* current = this->tl;

			/*while (current->pNext != nullptr)
			{
				current = current->pNext;
			}*/
			
			current = new Node(data);
			tl = current->pNext;

		}
		tail++;
		cnt++;
	}
}

int Queue_list::Dequeue()
{
	if (Queue_Empty())
	{
		cout << "Queue is already empty" << endl;
		return -1;
	}
	else
	{
		int index = cnt - 1;
		if (index == 0)
		{
			Node* temp = hd;

			hd = hd->pNext;
			int x = temp->data;

			delete temp;
			return x;
			cnt--;
		}
		else
		{
			Node* previous = this->hd;
			for (int i = 0; i < index - 1; i++)
			{
				previous = previous->pNext;
			}


			Node* toDelete = previous->pNext;

			previous->pNext = toDelete->pNext;
			int x = toDelete->data;
			delete toDelete;
			return x;
			cnt--;
		}
		head--;
	}
}

bool Queue_list::Queue_Empty()
{
	if (head == tail) return true;
	else return false;
}

bool Queue_list::Queue_Full()
{
	if (head == (tail + 1) % 20) return true;
	else return false;
}




