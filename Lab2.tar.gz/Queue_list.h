#pragma once
//#include "List.h"

struct Queue_list
{

	
	int head, tail;

	Queue_list()
	{
		head = tail = 0;
	}

	void Enqueue (int data);
	int Dequeue();
	bool Queue_Empty();
	bool Queue_Full();
	

	class Node
	{
	public:
		Node* pNext;
		int data;

		Node(int data = int(), Node* pNext = nullptr)
		{
			this->data = data;
			this->pNext = pNext;
		}
	};
	int cnt;
	Node* hd;
	Node* tl;

};

//bool Queue_Empty2(Queue_list A);
//bool Queue_Full2(Queue_list A);
//void Enqueue2(Queue_list A, int x);
//int Dequeue2(Queue_list A);