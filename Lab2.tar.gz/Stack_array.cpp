//#include "pch.h"
#include "Stack_array.h"
#include <iostream>
using namespace std;

bool Stack_Empty1(Stack_array A)
{
    if (A.cnt == 0) return true;
    else return false;
}

bool Stack_Full1(Stack_array A)
{
    if (A.cnt == 20) return true;
    else return false;
}

Stack_array Push1(Stack_array A, int x)
{
    if (Stack_Full1(A))
    {
        cout << "STACK OVERFLOW" << endl;
    }
    else
    {
        A.S[A.cnt] = x;
        A.cnt++;
        return A;
    }
}

Stack_array Pop1(Stack_array A)
{
    if (Stack_Empty1(A))
    {
        cout << "STACK UNDERFLOW" << endl;
        return A;
    }
    else
    {
        int y = A.S[A.cnt];
        A.cnt--;
        return A;
    }
}

void Stack_view1(Stack_array A)
{
    for (int i = 0; i < A.cnt; i++)
    {
        cout << A.S[i] << "  ";
    }
    cout << endl;
}
