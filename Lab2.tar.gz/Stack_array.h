#pragma once 
struct Stack_array
{

    int S[20] = {};
    int cnt;
    Stack_array()
    {
        cnt = 0;
    }


};

bool Stack_Empty1(Stack_array A);
bool Stack_Full1(Stack_array A);
Stack_array Push1(Stack_array A, int x);
Stack_array Pop1(Stack_array A);
void Stack_view1(Stack_array A);

