//#include "pch.h"
#include "Stack_list.h"
#include <iostream>
using namespace std;

//bool Stack_Empty2(Stack_list A)
//{
//	A.cnt = A.S.GetSize();
//	if (A.cnt == 0)return true;
//	else return false;
//	
//}
//
//bool Stack_Full2(Stack_list A)
//{
//	A.cnt = A.S.GetSize();
//	if (A.cnt == 20) return true;
//	else return false;
//}
//
//void Push2(Stack_list A, int x)
//{
//	A.cnt = A.S.GetSize();
//	if (Stack_Full2(A))
//	{
//		cout << "STACK OVERFLOW" << endl;
//	}
//	else
//	{
//		A.S.push_back(x);
//	}
//}
//
//int Pop2(Stack_list A)
//{
//	A.cnt = A.S.GetSize();
//	if (Stack_Empty2(A))
//	{
//		cout << "STACK UNDERFLOW" << endl;
//		return -1;
//	}
//	else
//	{
//		int x = A.S[(A.S.GetSize())];
//		A.S.pop_back();
//		return x;
//	}	
//}

void Stack_list::clear()
{
	while (cnt)
	{
		Pop();
	}
}

bool Stack_list::Stack_Empty()
{
	if (GetSize() == 0)return true;
	else return false;
}

bool Stack_list::Stack_Full()
{
	if (GetSize() == 20)return true;
	else return false;
}

int Stack_list::Pop()
{
	if (Stack_Empty())
	{
		cout << "STACK UNDERFLOW!" << endl;
		return -1;
	}
	else
	{
		int index = cnt - 1;
		if (index == 0)
		{
			Node* temp = head;
			
			//head = head->pNext;
			
	
			int x = temp->data;

			//delete temp;
			return x;
			cnt--;
		}
		else
		{
			Node* previous = this->head;
			for (int i = 0; i < index - 1; i++)
			{
				previous = previous->pNext;
			}


			Node* toDelete = previous->pNext;

			previous->pNext = toDelete->pNext;
			int x = toDelete->data;
			delete toDelete;
			return x;
			cnt--;
		}
	}
}

void Stack_list::Push(int data)
{
	if (Stack_Full())
	{
		cout << "STACK OVERFLOW!" << endl;
	}
	else
	{
		if (head == nullptr)
		{
			head = new Node(data);
		}
		else
		{
			Node* current = this->head;

			while (current->pNext != nullptr)
			{
				current = current->pNext;
			}
			current->pNext = new Node(data);

		}

		cnt++;
	}
}


