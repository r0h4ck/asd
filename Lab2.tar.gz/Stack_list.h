#pragma once
//#include "List.h"

struct Stack_list
{

	
	Stack_list()
	{
		cnt = 0;
		head = nullptr;
	}

	~Stack_list()
	{
		clear();
	}

	void clear();
	int GetSize() { return cnt; }
	bool Stack_Empty();
	bool Stack_Full();

	int Pop();
	void Push(int data);

private:
	class Node
	{
	public:
		Node* pNext;
		int data;

		/*Node(int data = {}, Node* pNext = nullptr)
		{
			this->data = data;
			this->pNext = pNext;
		}*/

		Node(int data = {})
		{
			this->data = data;
			this->pNext = nullptr;
		}
	};
	int cnt;
	Node* head;
};

//bool Stack_Empty2(Stack_list A);
//bool Stack_Full2(Stack_list A);
//void Push2(Stack_list A, int x);
//int Pop2(Stack_list A);